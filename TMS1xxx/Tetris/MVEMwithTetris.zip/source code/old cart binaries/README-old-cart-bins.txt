These dumps seem to be a few hours older than the ones in the folder above.

The other difference is that the ones above have been renamed to be front-end friendly for gamelists.
