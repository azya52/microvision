#lua ../Assembler/tmsasm.lua invaders.asm
make
cp *.h ../Arduino/Microvision
#./mvem pinball.bin
#cmp -b invaders.bin invaders.org
